from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QCheckBox, QPushButton, QHBoxLayout, QMessageBox
from ui.api_setup import ApiSetupDialog
from ui.dashboard import DashboardWindow

strategies = {
    "Low Risk": "Risk 0.5-1%, Leverage 1x-5x, Lot 0.01-0.2, RR 1:1.5+, SL 0.3-1%",
    "High Risk": "Risk 5-10%, Leverage 10x-50x, Lot 0.3-1.5, RR 1:1, SL 0.2-0.5",
    "Hybrid Adaptif": "Risk 1-3%, Leverage 3x-15x, Lot 0.2-0.8, RR 1:2+, SL 0.5-1%",
    "Compounding": "Profit otomatis diakumulasi ke modal (bisa gabung strategi lain)"
}

class StrategySelectDialog(QDialog):
    def __init__(self, mode):
        super().__init__()
        self.setWindowTitle("Pilih Strategi")
        self.mode = mode
        self.selected = []
        self.checks = []
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Pilih minimal 1, maksimal 2 strategi:"))
        hlayout = QHBoxLayout()
        for name, desc in strategies.items():
            cb = QCheckBox(name)
            cb.setToolTip(desc)
            cb.stateChanged.connect(self.limit_selection)
            self.checks.append(cb)
            hlayout.addWidget(cb)
        layout.addLayout(hlayout)
        self.next_btn = QPushButton("Lanjutkan")
        self.next_btn.setEnabled(False)
        self.next_btn.clicked.connect(self.confirm)
        layout.addWidget(self.next_btn)
        self.setLayout(layout)

    def limit_selection(self):
        checked = [c for c in self.checks if c.isChecked()]
        for c in self.checks:
            if len(checked) >= 2 and not c.isChecked():
                c.setEnabled(False)
            else:
                c.setEnabled(True)
        self.next_btn.setEnabled(len(checked) >= 1)
        self.selected = [c.text() for c in self.checks if c.isChecked()]

    def confirm(self):
        self.accept()
        if self.mode in ["real", "tournament"]:
            dlg = ApiSetupDialog(self.mode, self.selected)
            dlg.exec()
        else:
            dlg = DashboardWindow(self.mode, self.selected)
            dlg.show()
            dlg.exec()
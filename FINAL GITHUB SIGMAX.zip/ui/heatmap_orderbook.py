from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class HeatmapOrderBookTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Live Price Heatmap & Order Book Visualizer"))
        self.setLayout(layout)
from PyQt6.QtWidgets import QDialog, QTabWidget, QVBoxLayout, QLabel, QPushButton, QApplication
from ui.analytics import AnalyticsTab
from ui.log_tab import LogTab
from ui.backup_tab import BackupTab
from ui.help_tab import HelpTab
from core.engine import TradingEngine
from ui.theme import get_theme

import logging

class DashboardWindow(QDialog):
    def __init__(self, mode, strategies):
        super().__init__()
        self.setWindowTitle(f"SigmaX Dashboard - Mode: {mode.title()}")
        self.mode = mode
        self.strategies = strategies
        self.setFixedSize(980, 680)
        self.setStyleSheet(get_theme("dark"))
        layout = QVBoxLayout()
        label = QLabel(f"Mode: {mode.title()} | Strategi: {', '.join(strategies)}")
        label.setStyleSheet("font-size:16px; color:#4acaff;")
        layout.addWidget(label)
        self.tabs = QTabWidget()
        self.tabs.addTab(QLabel("Trading Lab & Status Panel"), "Dashboard")
        self.tabs.addTab(QLabel("Strategy Edit & Switch Panel"), "Strategy")
        self.tabs.addTab(AnalyticsTab(), "Analytics")
        self.tabs.addTab(LogTab(), "Log")
        self.tabs.addTab(BackupTab(), "Backup")
        self.tabs.addTab(HelpTab(), "Help")
        layout.addWidget(self.tabs)
        self.mini_btn = QPushButton("Mini Mode")
        self.mini_btn.clicked.connect(self.toggle_mini)
        layout.addWidget(self.mini_btn)
        self.setLayout(layout)
        self.engine = TradingEngine(mode, strategies)
        self.start_btn = QPushButton("Start Bot")
        self.start_btn.clicked.connect(self.start_bot)
        layout.addWidget(self.start_btn)
        self.stop_btn = QPushButton("Stop Bot")
        self.stop_btn.clicked.connect(self.stop_bot)
        layout.addWidget(self.stop_btn)
        from PyQt6.QtGui import QShortcut, QKeySequence
        self.shortcut_start = QShortcut(QKeySequence("Ctrl+S"), self)
        self.shortcut_start.activated.connect(self.start_bot)
        self.shortcut_stop = QShortcut(QKeySequence("Ctrl+Q"), self)
        self.shortcut_stop.activated.connect(self.stop_bot)

    def toggle_mini(self):
        QApplication.setOverrideCursor(0)
        self.setFixedSize(420, 220)

    def start_bot(self):
        logging.info("Starting bot from Dashboard")
        self.engine.start()

    def stop_bot(self):
        logging.info("Stopping bot from Dashboard")
        self.engine.stop()
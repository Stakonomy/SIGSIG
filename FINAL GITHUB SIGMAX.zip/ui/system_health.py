from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from core.watcher import check_resource

class SystemHealthTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.status = QLabel("System Health: OK")
        layout.addWidget(self.status)
        self.setLayout(layout)
        self.refresh()

    def refresh(self):
        overloaded = check_resource()
        self.status.setText("System Health: OVERLOAD" if overloaded else "System Health: OK")
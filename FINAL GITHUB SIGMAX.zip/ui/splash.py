from PyQt6.QtWidgets import QApplication, QDialog, QLabel, QVBoxLayout, QProgressBar
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QPixmap
from ui.mode_select import ModeSelectDialog
from ui.theme import get_theme
import sys

def show_splash():
    app = QApplication(sys.argv)
    splash = SplashScreen()
    splash.show()
    app.exec()

class SplashScreen(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SigmaX – KBWCKS")
        self.setFixedSize(400, 220)
        layout = QVBoxLayout()
        self.setStyleSheet(get_theme("dark"))
        pixmap = QPixmap("ui/assets/logo_sigmax.png")
        if not pixmap.isNull():
            logo = QLabel()
            logo.setPixmap(pixmap.scaled(96,96))
            layout.addWidget(logo)
        label = QLabel("SigmaX – KBWCKS\nAI Trading Bot\nThe Ultimate Market Dominator")
        label.setStyleSheet("font-size:20px; font-weight:bold; color:#4acaff;")
        layout.addWidget(label)
        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.setLayout(layout)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_progress)
        self.value = 0
        self.timer.start(20)

    def update_progress(self):
        self.value += 5
        self.progress.setValue(self.value)
        if self.value >= 100:
            self.timer.stop()
            self.accept()
            dlg = ModeSelectDialog()
            dlg.exec()
            self.close()
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class RiskDashboardTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Risk Exposure & Diversification"))
        self.setLayout(layout)
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
from ui.strategy_select import StrategySelectDialog

class ModeSelectDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pilih Mode SigmaX")
        self.setFixedSize(420, 220)
        layout = QVBoxLayout()
        label = QLabel("Pilih Mode Trading SigmaX")
        label.setStyleSheet("font-size:18px; font-weight:bold;")
        layout.addWidget(label)
        self.demo_btn = QPushButton("Demo Mode")
        self.real_btn = QPushButton("Real Trading")
        self.tour_btn = QPushButton("Tournament")
        hlayout = QHBoxLayout()
        for b in [self.demo_btn, self.real_btn, self.tour_btn]: hlayout.addWidget(b)
        layout.addLayout(hlayout)
        self.setLayout(layout)
        self.demo_btn.clicked.connect(lambda: self.goto_strategy("demo"))
        self.real_btn.clicked.connect(lambda: self.goto_strategy("real"))
        self.tour_btn.clicked.connect(lambda: self.goto_strategy("tournament"))

    def goto_strategy(self, mode):
        self.hide()
        dlg = StrategySelectDialog(mode)
        dlg.exec()
        self.close()
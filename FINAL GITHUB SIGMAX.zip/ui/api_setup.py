from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QComboBox, QLineEdit, QPushButton, QMessageBox
from core.exchange import EXCHANGES, check_api_key
from core.utils import load_config, save_config
from ui.dashboard import DashboardWindow

class ApiSetupDialog(QDialog):
    def __init__(self, mode, strategies):
        super().__init__()
        self.setWindowTitle("API Setup")
        self.mode = mode
        self.strategies = strategies
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Secure API Setup"))
        layout.addWidget(QLabel("Mode: " + str(mode).capitalize()))
        self.exchange = QComboBox()
        self.exchange.addItems(EXCHANGES)
        layout.addWidget(self.exchange)
        self.api_key = QLineEdit()
        self.api_key.setPlaceholderText("API Key")
        layout.addWidget(self.api_key)
        self.secret_key = QLineEdit()
        self.secret_key.setPlaceholderText("Secret Key")
        layout.addWidget(self.secret_key)
        self.btn = QPushButton("Connect Exchange")
        self.btn.clicked.connect(self.connect_api)
        layout.addWidget(self.btn)
        self.setLayout(layout)

    def connect_api(self):
        ex = self.exchange.currentText()
        key = self.api_key.text()
        sec = self.secret_key.text()
        if not check_api_key(key, sec, ex):
            QMessageBox.warning(self, "Error", "API Key & Secret wajib diisi dan valid")
            return
        cfg = load_config()
        cfg["api"] = {"exchange": ex, "api_key": key, "secret_key": sec}
        save_config(cfg)
        QMessageBox.information(self, "Sukses", f"API {ex} Connected!")
        self.accept()
        dlg = DashboardWindow(self.mode, self.strategies)
        dlg.show()
        dlg.exec()
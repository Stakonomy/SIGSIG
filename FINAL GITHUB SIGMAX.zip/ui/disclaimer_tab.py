from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class DisclaimerTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Disclaimer: SigmaX bukan penasihat keuangan. Risiko trading ditanggung user."))
        self.setLayout(layout)
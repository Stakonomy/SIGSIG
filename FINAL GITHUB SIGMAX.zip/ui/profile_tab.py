from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QListWidget

class ProfileTab(QWidget):
    def __init__(self, profiles):
        super().__init__()
        layout = QVBoxLayout()
        self.list = QListWidget()
        self.list.addItems([p["name"] for p in profiles])
        layout.addWidget(QLabel("Profiles"))
        layout.addWidget(self.list)
        self.setLayout(layout)
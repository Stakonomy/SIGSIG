def get_theme(mode="dark"):
    if mode == "dark":
        return """
        QWidget {
            background-color: #1c1c1c;
            color: #e0e0e0;
            font-family: "Segoe UI", "Arial";
        }
        QDialog, QTabWidget, QPushButton {
            background-color: #222;
            color: #4acaff;
        }
        QLineEdit, QComboBox, QCheckBox {
            background-color: #333;
            color: #e0e0e0;
            border: 1px solid #444;
        }
        QLabel {
            color: #4acaff;
        }
        """
    else:
        return """
        QWidget {
            background-color: #f5f5f5;
            color: #222;
            font-family: "Segoe UI", "Arial";
        }
        QDialog, QTabWidget, QPushButton {
            background-color: #fff;
            color: #0078d7;
        }
        QLineEdit, QComboBox, QCheckBox {
            background-color: #fff;
            color: #222;
            border: 1px solid #ccc;
        }
        QLabel {
            color: #0078d7;
        }
        """
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from core.utils import load_config, save_config, cloud_backup
import shutil

class BackupTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Backup & Restore Setting"))
        self.backup_btn = QPushButton("Backup Manual")
        self.backup_btn.clicked.connect(self.backup_manual)
        layout.addWidget(self.backup_btn)
        self.cloud_btn = QPushButton("Backup ke Cloud (Opsional)")
        self.cloud_btn.clicked.connect(lambda: cloud_backup("config.json"))
        layout.addWidget(self.cloud_btn)
        self.setLayout(layout)

    def backup_manual(self):
        shutil.copy("config.json", "backup/config_backup.json")
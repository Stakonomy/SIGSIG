from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from plugins import load_plugins

class PluginTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        plugins = load_plugins()
        layout.addWidget(QLabel(f"Plugins loaded: {len(plugins)}"))
        self.setLayout(layout)
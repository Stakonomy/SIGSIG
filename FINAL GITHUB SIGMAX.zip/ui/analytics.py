from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class AnalyticsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Grafik Equity, Drawdown, Winrate, dll"))
        self.setLayout(layout)
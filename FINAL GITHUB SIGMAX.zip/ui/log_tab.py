from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel

class LogTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Log Trading & System"))
        self.setLayout(layout)
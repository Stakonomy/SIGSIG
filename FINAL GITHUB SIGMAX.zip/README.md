# SigmaX BOT – KBWCKS

## Fitur Utama
- Trading bot modular multi-exchange
- OOP, logging, validasi input, backup/restore otomatis/manual
- UI PyQt6, bisa dijalankan di Linux/Windows/Termux
- Support deployment (Docker, exe), tidak ada backend luar/offline mode
- Konfigurasi terpisah, API key terenkripsi, multi-strategy, multi-profile

## Cara Jalankan
1. Install Python 3.10+ & pip
2. Install dependencies:
    ```
    pip install -r requirements.txt
    ```
3. Jalankan:
    ```
    python main.py
    ```

## Build .exe
Bisa menggunakan pyinstaller:
```
pyinstaller --onefile --windowed main.py
```

## Lisensi
Hak cipta SigmaX – KBWCKS. Dilarang memodifikasi branding tanpa izin.

## Disclaimer
SigmaX bukan penasihat keuangan. Risiko trading sepenuhnya di tangan user.
import unittest
from core.engine import TradingEngine

class TestEngine(unittest.TestCase):
    def test_start_stop(self):
        engine = TradingEngine("demo", ["Low Risk"])
        engine.start()
        self.assertTrue(engine.running)
        engine.stop()
        self.assertFalse(engine.running)

if __name__ == "__main__":
    unittest.main()
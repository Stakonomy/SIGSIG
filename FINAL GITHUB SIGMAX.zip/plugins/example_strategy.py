# Example plugin for SigmaX BOT
def run(data):
    # Simple MA crossover example
    price = data.get("price", 100)
    fast_ma = sum(data.get("prices", [price])) / max(len(data.get("prices", [])), 1)
    slow_ma = sum(data.get("prices", [price])) / max(len(data.get("prices", [])), 1)
    if fast_ma > slow_ma:
        return {"signal": "buy"}
    elif fast_ma < slow_ma:
        return {"signal": "sell"}
    else:
        return {"signal": "hold"}
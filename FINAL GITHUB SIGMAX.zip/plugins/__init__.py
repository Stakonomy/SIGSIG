import importlib
import os

def load_plugins():
    plugins = []
    path = os.path.dirname(__file__)
    for fname in os.listdir(path):
        if fname.endswith(".py") and fname != "__init__.py":
            mod = importlib.import_module(f"plugins.{fname[:-3]}")
            if hasattr(mod, "run"):
                plugins.append(mod)
    return plugins
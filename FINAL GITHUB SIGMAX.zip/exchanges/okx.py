class OKXHandler:
    def __init__(self, api_key, secret):
        self.api_key = api_key
        self.secret = secret

    def validate(self):
        return bool(self.api_key and self.secret)

    def get_balance(self):
        return 500.0

    def get_orderbook(self):
        return {"bids": [[99, 1]], "asks": [[100, 2]]}
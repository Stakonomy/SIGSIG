from .binance import BinanceHandler
from .okx import OKXHandler

EXCHANGE_HANDLERS = {
    "Binance": BinanceHandler,
    "OKX": OKXHandler,
    # Tambahkan handler lain sesuai kebutuhan
}

def get_handler(exchange_name):
    return EXCHANGE_HANDLERS.get(exchange_name)
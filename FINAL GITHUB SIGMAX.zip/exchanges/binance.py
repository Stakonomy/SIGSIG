class BinanceHandler:
    def __init__(self, api_key, secret):
        self.api_key = api_key
        self.secret = secret

    def validate(self):
        # Simulasi validasi
        return bool(self.api_key and self.secret)

    def get_balance(self):
        # Simulasi balance
        return 1000.0

    def get_orderbook(self):
        # Simulasi order book
        return {"bids": [[100, 2]], "asks": [[101, 3]]}
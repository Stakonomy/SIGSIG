import logging
from ui.splash import show_splash

def setup_logging():
    logging.basicConfig(
        filename="log/advanced.log",
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s"
    )
    logging.info("SigmaX BOT started.")

if __name__ == "__main__":
    setup_logging()
    show_splash()
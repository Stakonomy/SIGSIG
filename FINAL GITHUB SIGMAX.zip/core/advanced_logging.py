import logging

def setup_advanced_logging():
    logging.basicConfig(filename="log/advanced.log", level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")

def export_log_csv():
    with open("log/advanced.log") as f, open("log/advanced.csv","w") as out:
        for line in f:
            out.write(line.replace(" ", ","))
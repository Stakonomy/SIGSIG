def aggregate_accounts(account_data_list):
    total_balance = sum(acc["balance"] for acc in account_data_list)
    positions = [pos for acc in account_data_list for pos in acc.get("positions",[])]
    return {"total_balance": total_balance, "positions": positions}
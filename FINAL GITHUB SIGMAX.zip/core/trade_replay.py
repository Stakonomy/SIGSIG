import json

def save_trade_event(event):
    with open("log/trade_replay.json", "a") as f:
        f.write(json.dumps(event) + "\n")

def load_trade_events():
    with open("log/trade_replay.json") as f:
        return [json.loads(line) for line in f if line.strip()]
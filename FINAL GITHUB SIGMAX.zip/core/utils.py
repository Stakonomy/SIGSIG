from cryptography.fernet import Fernet
import logging
import os
import json

USER_DIR = os.path.expanduser("~/.sigmax77xx")
KEY_FILE = os.path.join(USER_DIR, "api_keys.enc")
PIN_FILE = os.path.join(USER_DIR, "lock.pin")

def generate_key():
    return Fernet.generate_key()

def encrypt_data(data, key):
    f = Fernet(key)
    return f.encrypt(data.encode())

def decrypt_data(token, key):
    f = Fernet(key)
    return f.decrypt(token).decode()

def load_config(config_path="config.json"):
    try:
        with open(config_path, "r") as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"Config load failed: {e}")
        return {}

def save_config(config, config_path="config.json"):
    try:
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        logging.error(f"Config save failed: {e}")

def save_pin(pin):
    with open(PIN_FILE, "w") as f:
        f.write(pin)

def check_pin(pin):
    try:
        with open(PIN_FILE) as f:
            return f.read() == pin
    except Exception:
        return False

def cloud_backup(file_path):
    print(f"Backup {file_path} ke cloud (opsional, next version)")

def exchange_info(exchange_name):
    info = {
        "Binance": {"supports": ["spot", "futures"], "leverage": [1,125], "min_lot": 0.001},
        "OKX": {"supports": ["spot", "futures"], "leverage": [1,100], "min_lot": 0.01},
    }
    return info.get(exchange_name, {})
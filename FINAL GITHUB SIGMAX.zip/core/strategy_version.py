import json
import datetime

def save_strategy_version(strategy, params):
    versions = []
    try:
        with open("strategy_versions.json") as f:
            versions = json.load(f)
    except Exception:
        pass
    versions.append({
        "timestamp": datetime.datetime.now().isoformat(),
        "strategy": strategy,
        "params": params
    })
    with open("strategy_versions.json","w") as f:
        json.dump(versions, f, indent=2)

def rollback_strategy_version(version_index):
    with open("strategy_versions.json") as f:
        versions = json.load(f)
    return versions[version_index]["params"]
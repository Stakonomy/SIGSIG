import random

STRATEGY_PRESET = {
    "Low Risk": {"risk": 1, "leverage": 3, "lot": 0.1, "rr": 1.5, "sl": 0.7},
    "High Risk": {"risk": 7, "leverage": 30, "lot": 0.9, "rr": 1, "sl": 0.35},
    "Hybrid Adaptif": {"risk": 2, "leverage": 7, "lot": 0.4, "rr": 2, "sl": 0.8},
    "Compounding": {"compound": True}
}

class StrategyManager:
    def __init__(self, strategies):
        self.strategies = strategies
        self.params = self.get_strategy_config(strategies)

    def get_strategy_config(self, selected):
        config = {}
        for s in selected:
            config.update(STRATEGY_PRESET.get(s, {}))
        return config

    def run_trade(self):
        # Simulasi hasil trade
        pnl = round(random.uniform(-self.params.get("risk", 1), self.params.get("risk", 1)), 2)
        return {"strategy": self.strategies, "pnl": pnl, "params": self.params}
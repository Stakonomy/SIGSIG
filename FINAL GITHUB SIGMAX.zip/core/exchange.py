import logging

EXCHANGES = [
    "Binance", "OKX", "Bybit", "Coinbase Exchange", "Kraken", "Bitfinex", "KuCoin",
    "HTX (Huobi)", "Gate.io", "MEXC", "Bitget", "BingX", "Crypto.com Exchange",
    "Phemex", "AscendEX (BitMax)", "CoinEx", "Deepcoin", "BitMart", "Poloniex", "XT.com",
    "IC Markets", "Pepperstone", "RoboForex", "FXTM", "Exness", "Eightcap", "XM",
    "Admirals", "Tickmill", "FXOpen", "FBS", "Alpari", "Deriv", "HFM", "OANDA"
]

def check_api_key(api_key, secret, exchange):
    if exchange not in EXCHANGES:
        logging.error(f"Exchange {exchange} not supported!")
        return False
    if not api_key or not secret:
        logging.error("API key validation failed: Empty key/secret")
        return False
    logging.info(f"API key validated for {exchange}")
    return True
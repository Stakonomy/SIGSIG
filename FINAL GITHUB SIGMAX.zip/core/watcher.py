import psutil
import logging

def check_resource():
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    logging.info(f"Resource check: CPU={cpu}%, RAM={mem}%")
    if cpu > 90 or mem > 90:
        logging.warning("Resource overload detected!")
        return True
    return False
import itertools

def auto_optimize(strategy, param_space, backtest_fn):
    best_score = None
    best_params = None
    for params in itertools.product(*param_space.values()):
        param_dict = dict(zip(param_space.keys(), params))
        score = backtest_fn(strategy, param_dict)
        if best_score is None or score > best_score:
            best_score = score
            best_params = param_dict
    return best_params, best_score
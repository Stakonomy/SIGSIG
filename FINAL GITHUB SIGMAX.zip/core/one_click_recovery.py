import shutil

def one_click_recovery():
    # Restore config and logs from backup
    shutil.copy("backup/config_backup.json", "config.json")
    shutil.copy("backup/log_backup.log", "log/advanced.log")
    print("Recovery sukses!")
import logging
from core.strategy import StrategyManager

class TradingEngine:
    def __init__(self, mode, strategies):
        self.mode = mode
        self.strategies = strategies
        self.running = False
        self.strategy_manager = StrategyManager(strategies)
        logging.info(f"Engine init mode={mode} strategies={strategies}")

    def start(self):
        if self.running:
            logging.warning("Engine already running.")
            return
        self.running = True
        logging.info("Trading Engine started")
        for i in range(3):
            trade = self.strategy_manager.run_trade()
            logging.info(f"Trade executed: {trade}")

    def stop(self):
        if not self.running:
            logging.warning("Engine already stopped.")
            return
        self.running = False
        logging.info("Trading Engine stopped")